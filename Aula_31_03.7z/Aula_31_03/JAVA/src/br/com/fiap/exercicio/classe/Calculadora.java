package br.com.fiap.exercicio.classe;

public class Calculadora {
	
	 void soma (int valor1, int valor2){
		
		System.out.println("a Soma � de: " + (valor1 + valor2));
	}
	 void subtracao (int valor1, int valor2){
			
			System.out.println("a subtra��o � de: " + (valor1 - valor2));
		}
	 void produto (int valor1, int valor2){
			
			System.out.println("o produto � de: " + (valor1 * valor2));
		}
	 void divisao (int valor1, int valor2){
			
			if (valor2 == 0) {
				
				System.out.println("opera��o invalida, impossivel realizar divis�o por 0 no conjunto dos nummeros reais!");
			} else {
				
				System.out.println("a divis�o � de: " + (valor1 / valor2));
			}
			
		}
	

}
