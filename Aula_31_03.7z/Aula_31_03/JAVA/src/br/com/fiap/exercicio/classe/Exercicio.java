package br.com.fiap.exercicio.classe;

public class Exercicio {

	//metodo main (ctrl + space)
	
	public static void main(String[] args) {
		
		//Instanciar o elevador
		
		Elevador elevador = new Elevador();
	
		//instanciar o total de andares e a capacidade
		
		elevador.inicializa(5,10);
		
		//subir um andar
		elevador.subir();
		
		System.out.println(elevador);
		
		
		//adicionar uma pessoa
		elevador.entra();
		
		//exibir o andar atual e a quantidade de pessoas no elevador
		
		System.out.println("o Andar atual �:" + elevador.andarAtual);
		System.out.println("quantidade total de pessoa:" + elevador.capacidadeAtual);
		
		
		//exibir o total de andares a a capacidade
		
		System.out.println("o Andar total �:" + elevador.totalAndar);
		System.out.println("quantidade total de pessoa:" + elevador.capacidadeTotal);
		
		System.out.println("FIM, fodasse");
	
		
		
		
	}
	
}
