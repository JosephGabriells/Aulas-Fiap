package br.com.fiap.collections.view;

import java.util.ArrayList;
import java.util.List;
import br.com.fiap.collections.model.Filme;

public class ExemploListFilmes {

	public static void main(String[] args) {
		// Criar uma lista de Filmes
		List <Filme> filmes = new ArrayList<>();
		
		// Adicionar 2 filmes na lista
		filmes.add(new Filme("Avatar", 90, "Tiro"));
		filmes.add(new Filme("Yuri Alberto: O Retorno", 100, "Esporte"));
		
		// Exibir os dados do filme da lista
		for (int i = 0; i < filmes.size(); i++) {
			System.out.println("--------------------------");
			System.out.println(filmes.get(i).getNome());
			System.out.println(filmes.get(i).getDuracao());
			System.out.println(filmes.get(i).getGenero());
		}
		
		
	}

}
