package br.com.fiap.collections.view;

import java.util.HashSet;
import java.util.Set;

public class ExempleSet {
	
	public static void main(String[] args) {
	// Criar um conjunto de String(Nomes de Séries)
	Set<String> conjunto = new HashSet<>();
	
	// Adicionar 2 séries 
	conjunto.add("Breaking Bad");
	conjunto.add("Game Of Thrones");
	conjunto.add("Suits");
	conjunto.add("Better Call Saul");

	
	// Exibir a quantidade de séries no conjunto
	System.out.println(conjunto.size());
	
	// Exibir os elementos do conjunto
	for(String serie: conjunto) {
		System.out.println(serie);
	}
	
	String cu = "suits";
	
	// Verificar se a série The Boys está no conjunto
	System.out.println(conjunto.contains(cu.toLowerCase()));
	}
}
