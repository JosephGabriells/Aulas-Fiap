package br.com.fiap.collections.view;

import java.util.List;
import java.util.ArrayList;

public class ExemploList {

	public static void main(String[] args) {
		
		// Instancia um ArrayList, não pode ser apenas list pois não possui os métodos
		List<Integer> lista = new ArrayList<Integer>(); 
		
		// Adicionando um elemento na lista
		lista.add(10);
		lista.add(9);
		
		for (int i = 0; i < 5; i++) {
			lista.add(i);
		}
		
		// Adicionar um elemento na segunda posição
			// index, elemento
		lista.add(3, 50);
		System.out.println(lista);
		
		
		// Remover um elemento da lista
		lista.remove(0);
		
		
		// Substitui um elemento na lista
		lista.set(0, 5);
		
		
		// Exibir a quantidade de elementos na lista
		System.out.println(lista.size());
		
		
		// Recuperando o primeiro elemento da lista
		System.out.println(lista.get(0));
		
		
		// Exibir os elementos da lista
		System.out.println(lista);
		
		for (int numero : lista) {System.out.println(numero);}
		
		
		// Verificar se existe elementos na lista
		System.out.println(lista.isEmpty());
		
		
		
	}
	
}
